#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structlar
typedef struct {
    long long int piyadeler;
    long long int okcular;
    long long int suvariler;
    long long int kusatma_makineleri;
} InsanBirimler;

typedef struct {
    long long int ork_dovusculeri;
    long long int mizrakcilar;
    long long int varg_binicileri;
    long long int troller;
} OrkBirimler;


typedef struct {
    int savunma_ustaligi;
    int saldiri_gelistirmesi;
} ArastirmaSeviyesi;

typedef struct {
    InsanBirimler insan_birimler;
    OrkBirimler ork_birimler;
} Imparatorluk;

typedef struct {
    int saldiri;
    int savunma;
    int saglik;
    int kritik_sans;
} BirimOzellikleri;

typedef struct {
    int bonus_degeri;
    char bonus_turu[50];
} KahramanBonus;

typedef struct {
    int etki_degeri;
    char etki_turu[50];
} CanavarEtki;

typedef struct {
    int deger;
    char aciklama[100];
} ArastirmaSeviyesiEtki;

long long int toplam_hesapla(long long int birim_sayisi, int birim_degeri) {
    return birim_sayisi * birim_degeri;
}

void json_oku(char *filename, const char *imparatorluk_turu, Imparatorluk *imparatorluk, ArastirmaSeviyesi *arastirma) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        printf("Dosya açılamadı: %s\n", filename);
        return;
    }

    char buffer[1024];
    while (fgets(buffer, 1024, file)) {
        char *p = buffer;
        while (*p != '\0') {
            if (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t') {
                p++;
                continue;
            }

            if (strcmp(imparatorluk_turu, "insan_imparatorlugu") == 0) {
                // İnsan İmparatorluğu Birimleri
                if (strstr(p, "\"piyadeler\":") == p) {
                    sscanf(p, "\"piyadeler\": %lld", &imparatorluk->insan_birimler.piyadeler);
                } else if (strstr(p, "\"okcular\":") == p) {
                    sscanf(p, "\"okcular\": %lld", &imparatorluk->insan_birimler.okcular);
                } else if (strstr(p, "\"suvariler\":") == p) {
                    sscanf(p, "\"suvariler\": %lld", &imparatorluk->insan_birimler.suvariler);
                } else if (strstr(p, "\"kusatma_makineleri\":") == p) {
                    sscanf(p, "\"kusatma_makineleri\": %lld", &imparatorluk->insan_birimler.kusatma_makineleri);
                } else if (strstr(p, "\"savunma_ustaligi\":") == p) {
                    sscanf(p, "\"savunma_ustaligi\": %d", &arastirma->savunma_ustaligi);
                } else if (strstr(p, "\"saldiri_gelistirmesi\":") == p) {
                    sscanf(p, "\"saldiri_gelistirmesi\": %d", &arastirma->saldiri_gelistirmesi);
                }
            } else if (strcmp(imparatorluk_turu, "ork_legi") == 0) {
                // Ork Lejyonu Birimleri
                if (strstr(p, "\"ork_dovusculeri\":") == p) {
                    sscanf(p, "\"ork_dovusculeri\": %lld", &imparatorluk->ork_birimler.ork_dovusculeri);
                } else if (strstr(p, "\"mizrakcilar\":") == p) {
                    sscanf(p, "\"mizrakcilar\": %lld", &imparatorluk->ork_birimler.mizrakcilar);
                } else if (strstr(p, "\"varg_binicileri\":") == p) {
                    sscanf(p, "\"varg_binicileri\": %lld", &imparatorluk->ork_birimler.varg_binicileri);
                } else if (strstr(p, "\"troller\":") == p) {
                    sscanf(p, "\"troller\": %lld", &imparatorluk->ork_birimler.troller);
                } else if (strstr(p, "\"savunma_ustaligi\":") == p) {
                    sscanf(p, "\"savunma_ustaligi\": %d", &arastirma->savunma_ustaligi);
                } else if (strstr(p, "\"saldiri_gelistirmesi\":") == p) {
                    sscanf(p, "\"saldiri_gelistirmesi\": %d", &arastirma->saldiri_gelistirmesi);
                }
            }

            break;
        }
    }

    fclose(file);
}


// Dosyanın tamamını belleğe okuma fonksiyonu
char *dosyayi_oku(const char *filename) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        printf("Dosya açılamadı: %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long dosya_boyutu = ftell(file);
    rewind(file);

    char *icerik = (char *)malloc(dosya_boyutu + 1);
    if (!icerik) {
        printf("Bellek ayırma hatası\n");
        fclose(file);
        return NULL;
    }

    fread(icerik, 1, dosya_boyutu, file);
    icerik[dosya_boyutu] = '\0'; // Null-terminate
    fclose(file);
    return icerik;
}

// Birim özelliklerini JSON'dan ayrıştırma fonksiyonu
void birim_ozelliklerini_ayristir(const char *json_data, const char *birim_adi, BirimOzellikleri *birim) {
    char arama_kalibi[100];
    sprintf(arama_kalibi, "\"%s\":", birim_adi);

    char *birim_bolumu = strstr(json_data, arama_kalibi);
    if (!birim_bolumu) {
        printf("Birim bulunamadı: %s\n", birim_adi);
        return;
    }

    // Saldırı
    char *saldiri_bolumu = strstr(birim_bolumu, "\"saldiri\":");
    if (saldiri_bolumu) {
        sscanf(saldiri_bolumu, "\"saldiri\": %d,", &birim->saldiri);
    }

    // Savunma
    char *savunma_bolumu = strstr(birim_bolumu, "\"savunma\":");
    if (savunma_bolumu) {
        sscanf(savunma_bolumu, "\"savunma\": %d,", &birim->savunma);
    }

    // Sağlık
    char *saglik_bolumu = strstr(birim_bolumu, "\"saglik\":");
    if (saglik_bolumu) {
        sscanf(saglik_bolumu, "\"saglik\": %d,", &birim->saglik);
    }

    // Kritik şans
    char *kritik_bolumu = strstr(birim_bolumu, "\"kritik_sans\":");
    if (kritik_bolumu) {
        sscanf(kritik_bolumu, "\"kritik_sans\": %d", &birim->kritik_sans);
    }
}

void arastirma_seviyesi_ayristir(const char *research_data, const char *imparatorluk_turu, ArastirmaSeviyesi *arastirma, ArastirmaSeviyesiEtki *savunma_ustaligi, ArastirmaSeviyesiEtki *saldiri_gelistirmesi) {
    // Savunma Ustalığı seviyesini kontrol et ve ayrıştır
    if (arastirma->savunma_ustaligi > 0) {
        char arama_kalibi[150];
        sprintf(arama_kalibi, "\"savunma_ustaligi\"", arastirma->savunma_ustaligi);

        char *savunma_bolumu = strstr(research_data, arama_kalibi);
        if (savunma_bolumu) {
            // Değeri al
            char *deger_bolumu = strstr(savunma_bolumu, "\"deger\":");
            if (deger_bolumu) {
                sscanf(deger_bolumu, "\"deger\": %d,", &savunma_ustaligi->deger);
            }
            // Açıklamayı al
            char *aciklama_bolumu = strstr(savunma_bolumu, "\"aciklama\":");
            if (aciklama_bolumu) {
                sscanf(aciklama_bolumu, "\"aciklama\": \"%[^\"]\"", savunma_ustaligi->aciklama);
            }
        } else {
            printf("Savunma Ustalığı bonusu bulunamadı (seviye %d).\n", arastirma->savunma_ustaligi);
        }
    }

    // Saldırı Geliştirmesi seviyesini kontrol et ve ayrıştır
    if (arastirma->saldiri_gelistirmesi > 0) {
        char arama_kalibi[150];
        sprintf(arama_kalibi, "\"saldiri_gelistirmesi\"", arastirma->saldiri_gelistirmesi);

        char *saldiri_bolumu = strstr(research_data, arama_kalibi);
        if (saldiri_bolumu) {
            // Değeri al
            char *deger_bolumu = strstr(saldiri_bolumu, "\"deger\":");
            if (deger_bolumu) {
                sscanf(deger_bolumu, "\"deger\": %d,", &saldiri_gelistirmesi->deger);
            }
            // Açıklamayı al
            char *aciklama_bolumu = strstr(saldiri_bolumu, "\"aciklama\":");
            if (aciklama_bolumu) {
                sscanf(aciklama_bolumu, "\"aciklama\": \"%[^\"]\"", saldiri_gelistirmesi->aciklama);
            }
        } else {
            printf("Saldırı Geliştirmesi bonusu bulunamadı (seviye %d).\n", arastirma->saldiri_gelistirmesi);
        }
    }
}



// Kahraman etkilerini JSON'dan ayrıştırma fonksiyonu
void kahraman_bonusu_ayristir(const char *json_data, const char *kahraman_adi, KahramanBonus *kahraman) {
    char arama_kalibi[100];
    sprintf(arama_kalibi, "\"%s\":", kahraman_adi);

    char *kahraman_bolumu = strstr(json_data, arama_kalibi);
    if (!kahraman_bolumu) {
        printf("Kahraman bulunamadı: %s\n", kahraman_adi);
        return;
    }

    // Bonus Türü
    char *bonus_turu_bolumu = strstr(kahraman_bolumu, "\"bonus_turu\":");
    if (bonus_turu_bolumu) {
        sscanf(bonus_turu_bolumu, "\"bonus_turu\": \"%[^\"]\"", kahraman->bonus_turu);
    }

    // Bonus Değeri
    char *bonus_degeri_bolumu = strstr(kahraman_bolumu, "\"bonus_degeri\":");
    if (bonus_degeri_bolumu) {
        sscanf(bonus_degeri_bolumu, "\"bonus_degeri\": %d,", &kahraman->bonus_degeri);
    }
}

// Canavar etkilerini JSON'dan ayrıştırma fonksiyonu
void canavar_etkisi_ayristir(const char *json_data, const char *canavar_adi, CanavarEtki *canavar) {
    char arama_kalibi[100];
    sprintf(arama_kalibi, "\"%s\":", canavar_adi);

    char *canavar_bolumu = strstr(json_data, arama_kalibi);
    if (!canavar_bolumu) {
        printf("Canavar bulunamadı: %s\n", canavar_adi);
        return;
    }

    // Etki Türü
    char *etki_turu_bolumu = strstr(canavar_bolumu, "\"etki_turu\":");
    if (etki_turu_bolumu) {
        sscanf(etki_turu_bolumu, "\"etki_turu\": \"%[^\"]\"", canavar->etki_turu);
    }

    // Etki Değeri
    char *etki_degeri_bolumu = strstr(canavar_bolumu, "\"etki_degeri\":");
    if (etki_degeri_bolumu) {
        sscanf(etki_degeri_bolumu, "\"etki_degeri\": %d,", &canavar->etki_degeri);
    }
}

// Bonusları birimlere uygulama fonksiyonu
void bonuslari_uygula(BirimOzellikleri *birim, int bonus_yuzdesi, int bonus_turu) {
    if (bonus_turu == 0) { // Savunma Bonus
        birim->savunma += (birim->savunma * bonus_yuzdesi) / 100;
    } else if (bonus_turu == 1) { // Saldırı Bonus
        birim->saldiri += (birim->saldiri * bonus_yuzdesi) / 100;
    }
}

// Hasar hesaplama fonksiyonu
long long int hasar_hesapla(long long int toplam_saldiri, long long int toplam_savunma) {
    long long int net_hasar = toplam_saldiri - toplam_savunma;
    return (net_hasar > 0) ? net_hasar : 0;
}

// Hasarın birimlere dağıtılması
void hasar_dagit_ve_guncelle(long long int hasar, long long int savunma_1, long long int savunma_2, long long int *saglik_1, long long int *saglik_2) {
    if (hasar == 0) return;

    // Savunma oranlarına göre hasarı dağıt
    long long int toplam_savunma = savunma_1 + savunma_2;
    double oran_1 = (double)savunma_1 / toplam_savunma;
    double oran_2 = (double)savunma_2 / toplam_savunma;

    long long int hasar_1 = (long long int)(hasar * oran_1);
    long long int hasar_2 = (long long int)(hasar * oran_2);

    *saglik_1 -= hasar_1;
    *saglik_2 -= hasar_2;

    // Sağlık 0 altına düşerse sıfırla
    if (*saglik_1 < 0) *saglik_1 = 0;
    if (*saglik_2 < 0) *saglik_2 = 0;
}

// Tur bazlı savaş fonksiyonu
void savas_turu(Imparatorluk *insan, Imparatorluk *ork, BirimOzellikleri insan_ozellikleri[], BirimOzellikleri ork_ozellikleri[], int tur) {
    long long int toplam_saldiri_insan = toplam_hesapla(insan->insan_birimler.piyadeler, insan_ozellikleri[0].saldiri) +
                                         toplam_hesapla(insan->insan_birimler.suvariler, insan_ozellikleri[2].saldiri);

    long long int toplam_savunma_ork = toplam_hesapla(ork->ork_birimler.ork_dovusculeri, ork_ozellikleri[0].savunma) +
                                       toplam_hesapla(ork->ork_birimler.mizrakcilar, ork_ozellikleri[1].savunma);

    long long int net_hasar = hasar_hesapla(toplam_saldiri_insan, toplam_savunma_ork);

    // Hasarı orklara dağıt ve sağlıklarını güncelle
    hasar_dagit_ve_guncelle(net_hasar, ork->ork_birimler.ork_dovusculeri * ork_ozellikleri[0].savunma,
                            ork->ork_birimler.mizrakcilar * ork_ozellikleri[1].savunma,
                            &ork_ozellikleri[0].saglik, &ork_ozellikleri[1].saglik);

    //printf("Tur %d: İnsanlar saldırdı, Orklar %lld hasar aldı.\n", tur, net_hasar);

    // Eğer ork birimleri yoksa oyundan çıkar
    if (ork_ozellikleri[0].saglik == 0) {
        ork->ork_birimler.ork_dovusculeri = 0;
        printf("Ork Dövüşçüleri yok oldu!\n");
    }
    if (ork_ozellikleri[1].saglik == 0) {
        ork->ork_birimler.mizrakcilar = 0;
        printf("Ork Mızrakçıları yok oldu!\n");
    }
}

// Tur bazlı savaş fonksiyonu
void savas_turu2(Imparatorluk *ork, Imparatorluk *insan, BirimOzellikleri ork_ozellikleri[], BirimOzellikleri insan_ozellikleri[], int tur) {
    long long int toplam_saldiri_ork = toplam_hesapla(ork->ork_birimler.ork_dovusculeri, ork_ozellikleri[0].saldiri) +
                                       toplam_hesapla(ork->ork_birimler.mizrakcilar, ork_ozellikleri[1].saldiri);

    long long int toplam_savunma_insan = toplam_hesapla(insan->insan_birimler.piyadeler, insan_ozellikleri[0].savunma) +
                                         toplam_hesapla(insan->insan_birimler.okcular, insan_ozellikleri[1].savunma) +
                                         toplam_hesapla(insan->insan_birimler.suvariler, insan_ozellikleri[2].savunma);

    long long int net_hasar = hasar_hesapla(toplam_saldiri_ork, toplam_savunma_insan);

    // Hasarı insanlara dağıt ve sağlıklarını güncelle
    hasar_dagit_ve_guncelle(net_hasar, insan->insan_birimler.piyadeler * insan_ozellikleri[0].savunma,
                            insan->insan_birimler.okcular * insan_ozellikleri[1].savunma,
                            &insan_ozellikleri[0].saglik, &insan_ozellikleri[1].saglik);

    //printf("Tur %d: Orklar saldırdı, İnsanlar %lld hasar aldı.\n", tur, net_hasar);

    // Eğer insan birimleri yoksa oyundan çıkar
    if (insan_ozellikleri[0].saglik == 0) {
        insan->insan_birimler.piyadeler = 0;
        printf("Piyadeler yok oldu!\n");
    }

    if (insan_ozellikleri[2].saglik == 0) {
        insan->insan_birimler.suvariler = 0;
        printf("Süvariler yok oldu!\n");
    }
}

// Savaş bitiş kontrolü
int savas_bitti_mi(Imparatorluk *imparatorluk, BirimOzellikleri birim_ozellikleri[], int insan_mi) {
    long long int toplam_saglik = birim_ozellikleri[0].saglik + birim_ozellikleri[1].saglik;
    if (toplam_saglik == 0) {
        if (insan_mi) {
            printf("İnsan İmparatorluğu kaybetti!\n");
        } else {
            printf("Ork Lejyonu kaybetti!\n");
        }
        return 1; // Savaş bitti
    }
    return 0; // Savaş devam ediyor
}

int main() {
    Imparatorluk insan_imparatorlugu = {0};
    Imparatorluk ork_legi = {0};
    ArastirmaSeviyesi insan_arastirma = {0};
    ArastirmaSeviyesi ork_arastirma = {0};

    // JSON dosyalarını okuma
    json_oku("1.json", "insan_imparatorlugu", &insan_imparatorlugu, &insan_arastirma);
    json_oku("1.json", "ork_legi", &ork_legi, &ork_arastirma);

    char *unit_types_data = dosyayi_oku("unit_types.json");
    if (!unit_types_data) return 1;

    char *research_data = dosyayi_oku("research.json");
    if (!research_data) return 1;


    // Araştırma seviyeleri etkilerini tanımlama
    ArastirmaSeviyesiEtki savunma_ustaligi = {0};
    ArastirmaSeviyesiEtki saldiri_gelistirmesi = {0};

    // Araştırma seviyelerini ayrıştırma (İnsan İmparatorluğu)
    arastirma_seviyesi_ayristir(research_data, "insan_imparatorlugu", &insan_arastirma, &savunma_ustaligi, &saldiri_gelistirmesi);

    BirimOzellikleri insan_ozellikleri[3];
    BirimOzellikleri ork_ozellikleri[2];

    birim_ozelliklerini_ayristir(unit_types_data, "piyadeler", &insan_ozellikleri[0]);
    birim_ozelliklerini_ayristir(unit_types_data, "okcular", &insan_ozellikleri[1]);
    birim_ozelliklerini_ayristir(unit_types_data, "suvariler", &insan_ozellikleri[2]);

    birim_ozelliklerini_ayristir(unit_types_data, "ork_dovusculeri", &ork_ozellikleri[0]);
    birim_ozelliklerini_ayristir(unit_types_data, "mizrakcilar", &ork_ozellikleri[1]);

   /* // Bonusları uygulama (İnsan İmparatorluğu)
    if (insan_arastirma.savunma_ustaligi > 0) {
        bonuslari_uygula(&piyade_ozellikleri, savunma_ustaligi.deger, 0);
        bonuslari_uygula(&okcu_ozellikleri, savunma_ustaligi.deger, 0);
        bonuslari_uygula(&suvari_ozellikleri, savunma_ustaligi.deger, 0);
    }
    if (insan_arastirma.saldiri_gelistirmesi > 0) {
        bonuslari_uygula(&piyade_ozellikleri, saldiri_gelistirmesi.deger, 1);
        bonuslari_uygula(&okcu_ozellikleri, saldiri_gelistirmesi.deger, 1);
        bonuslari_uygula(&suvari_ozellikleri, saldiri_gelistirmesi.deger, 1);
    }

    // Bonusları uygulama (Ork Lejyonu)
    ArastirmaSeviyesiEtki ork_savunma_ustaligi = {0};
    ArastirmaSeviyesiEtki ork_saldiri_gelistirmesi = {0};
    arastirma_seviyesi_ayristir(research_data, "ork_legi", &ork_arastirma, &ork_savunma_ustaligi, &ork_saldiri_gelistirmesi);
    printf("%d", ork_savunma_ustaligi.deger);
    if (ork_arastirma.savunma_ustaligi > 0) {
        bonuslari_uygula(&ork_dovusculeri_ozellikleri, ork_arastirma.savunma_ustaligi, 0);
        bonuslari_uygula(&mizrakcilar_ozellikleri, ork_arastirma.savunma_ustaligi, 0);
        bonuslari_uygula(&varg_binicileri_ozellikleri, ork_arastirma.savunma_ustaligi, 0);
        bonuslari_uygula(&troller_ozellikleri, ork_arastirma.savunma_ustaligi, 0);
    }
    printf("%d", ork_arastirma.saldiri_gelistirmesi);
    if (ork_arastirma.saldiri_gelistirmesi > 0) {
        bonuslari_uygula(&ork_dovusculeri_ozellikleri, ork_arastirma.saldiri_gelistirmesi, 1);
        bonuslari_uygula(&mizrakcilar_ozellikleri, ork_arastirma.saldiri_gelistirmesi, 1);
        bonuslari_uygula(&varg_binicileri_ozellikleri, ork_arastirma.saldiri_gelistirmesi, 1);
        bonuslari_uygula(&troller_ozellikleri, ork_arastirma.saldiri_gelistirmesi, 1);
    }
    printf("%d\n", insan_arastirma.savunma_ustaligi);
    // Toplam sağlık hesaplama (İnsan İmparatorluğu)
    long long int toplam_saglik_piyade = toplam_hesapla(insan_imparatorlugu.insan_birimler.piyadeler, piyade_ozellikleri.saglik);
    long long int toplam_saglik_okcu = toplam_hesapla(insan_imparatorlugu.insan_birimler.okcular, okcu_ozellikleri.saglik);
    long long int toplam_saglik_suvari = toplam_hesapla(insan_imparatorlugu.insan_birimler.suvariler, suvari_ozellikleri.saglik);

    // Toplam saldırı hesaplama (İnsan İmparatorluğu)
    long long int toplam_saldiri_piyade = toplam_hesapla(insan_imparatorlugu.insan_birimler.piyadeler, piyade_ozellikleri.saldiri);
    long long int toplam_saldiri_okcu = toplam_hesapla(insan_imparatorlugu.insan_birimler.okcular, okcu_ozellikleri.saldiri);
    long long int toplam_saldiri_suvari = toplam_hesapla(insan_imparatorlugu.insan_birimler.suvariler, suvari_ozellikleri.saldiri);

    // Toplam savunma hesaplama (İnsan İmparatorluğu)
    long long int toplam_savunma_piyade = toplam_hesapla(insan_imparatorlugu.insan_birimler.piyadeler, piyade_ozellikleri.savunma);
    long long int toplam_savunma_okcu = toplam_hesapla(insan_imparatorlugu.insan_birimler.okcular, okcu_ozellikleri.savunma);
    long long int toplam_savunma_suvari = toplam_hesapla(insan_imparatorlugu.insan_birimler.suvariler, suvari_ozellikleri.savunma);

    // Toplam kritik şans hesaplama (İnsan İmparatorluğu)
    long long int toplam_kritik_sans_piyade = toplam_hesapla(insan_imparatorlugu.insan_birimler.piyadeler, piyade_ozellikleri.kritik_sans);
    long long int toplam_kritik_sans_okcu = toplam_hesapla(insan_imparatorlugu.insan_birimler.okcular, okcu_ozellikleri.kritik_sans);
    long long int toplam_kritik_sans_suvari = toplam_hesapla(insan_imparatorlugu.insan_birimler.suvariler, suvari_ozellikleri.kritik_sans);

    // Toplam sağlık hesaplama (Ork Lejyonu)
    long long int toplam_saglik_ork_dovuscu = toplam_hesapla(ork_legi.ork_birimler.ork_dovusculeri, ork_dovusculeri_ozellikleri.saglik);
    long long int toplam_saglik_mizrakci = toplam_hesapla(ork_legi.ork_birimler.mizrakcilar, mizrakcilar_ozellikleri.saglik);
    long long int toplam_saglik_varg_binici = toplam_hesapla(ork_legi.ork_birimler.varg_binicileri, varg_binicileri_ozellikleri.saglik);
    long long int toplam_saglik_troller = toplam_hesapla(ork_legi.ork_birimler.troller, troller_ozellikleri.saglik);

    // Toplam saldırı hesaplama (Ork Lejyonu)
    long long int toplam_saldiri_ork_dovuscu = toplam_hesapla(ork_legi.ork_birimler.ork_dovusculeri, ork_dovusculeri_ozellikleri.saldiri);
    long long int toplam_saldiri_mizrakci = toplam_hesapla(ork_legi.ork_birimler.mizrakcilar, mizrakcilar_ozellikleri.saldiri);
    long long int toplam_saldiri_varg_binici = toplam_hesapla(ork_legi.ork_birimler.varg_binicileri, varg_binicileri_ozellikleri.saldiri);
    long long int toplam_saldiri_troller = toplam_hesapla(ork_legi.ork_birimler.troller, troller_ozellikleri.saldiri);

    // Toplam savunma hesaplama (Ork Lejyonu)
    long long int toplam_savunma_ork_dovuscu = toplam_hesapla(ork_legi.ork_birimler.ork_dovusculeri, ork_dovusculeri_ozellikleri.savunma);
    long long int toplam_savunma_mizrakci = toplam_hesapla(ork_legi.ork_birimler.mizrakcilar, mizrakcilar_ozellikleri.savunma);
    long long int toplam_savunma_varg_binici = toplam_hesapla(ork_legi.ork_birimler.varg_binicileri, varg_binicileri_ozellikleri.savunma);
    long long int toplam_savunma_troller = toplam_hesapla(ork_legi.ork_birimler.troller, troller_ozellikleri.savunma);

    // Toplam kritik şans hesaplama (Ork Lejyonu)
    long long int toplam_kritik_sans_ork_dovuscu = toplam_hesapla(ork_legi.ork_birimler.ork_dovusculeri, ork_dovusculeri_ozellikleri.kritik_sans);
    long long int toplam_kritik_sans_mizrakci = toplam_hesapla(ork_legi.ork_birimler.mizrakcilar, mizrakcilar_ozellikleri.kritik_sans);
    long long int toplam_kritik_sans_varg_binici = toplam_hesapla(ork_legi.ork_birimler.varg_binicileri, varg_binicileri_ozellikleri.kritik_sans);
    long long int toplam_kritik_sans_troller = toplam_hesapla(ork_legi.ork_birimler.troller, troller_ozellikleri.kritik_sans);
*/
 // Tur bazlı savaş döngüsü
    int tur = 1;
    while (1) {
        // İnsanlar saldırır
        savas_turu(&insan_imparatorlugu, &ork_legi, insan_ozellikleri, ork_ozellikleri, tur);

        // Savaş bitti mi?
        if (savas_bitti_mi(&ork_legi, ork_ozellikleri, 0)) break;

        // Orklar saldırır
        savas_turu2(&ork_legi, &insan_imparatorlugu, ork_ozellikleri, insan_ozellikleri, tur + 1);
        // Savaş bitti mi?
        if (savas_bitti_mi(&insan_imparatorlugu, insan_ozellikleri, 1)) break;

        tur += 2; // Her iki taraf birer tur saldırmış olur
    }

    // Bellek temizleme
    free(unit_types_data);

    return 0;
}
