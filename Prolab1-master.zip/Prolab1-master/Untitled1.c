
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Birim t�r� yap�s�
typedef struct {
    char name[50];
    int attack;
    int defense;
    int health;
    float critical_chance; // Oran olarak 0.05 gibi
} UnitType;

// Kahraman yap�s�
typedef struct {
    char name[50];
    char unit_type[50]; // Hangi birime bonus verdi�i
    float bonus_amount; // �rne�in %20 i�in 0.20
    int bonus_type; // 0: Attack, 1: Defense
} Hero;

// Canavar yap�s�
typedef struct {
    char name[50];
    float attack_bonus;
    float defense_penalty;
} Creature;

// Ara�t�rma yap�s�
typedef struct {
    char name[50];
    int level;
    char affected_unit[50];
    float bonus_amount;
    int bonus_type; // 0: Attack, 1: Defense, 2: Critical Chance
} Research;
