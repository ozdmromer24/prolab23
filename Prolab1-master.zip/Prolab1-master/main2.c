// Windows API fonksiyonlarını yeniden adlandır
#define CloseWindow CloseWindowWin
#define ShowCursor ShowCursorWin
#define LoadImage LoadImageWin
#define DrawText DrawTextWin
#define DrawTextEx DrawTextExWin
#define PlaySound PlaySoundWin

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// Windows API fonksiyonlarını geri al
#undef CloseWindow
#undef ShowCursor
#undef LoadImage
#undef DrawText
#undef DrawTextEx
#undef PlaySound

// Raylib'i dahil et
#define RAYLIB_IMPLEMENTATION
#define GRAPHICS_API_OPENGL_33
#include <raylib.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "include/curl/curl.h"

// Birim tanımı
typedef struct {
    char *isim;
    int saldiri;
    int savunma;
    int saglik;
    int maksimumSaglik;
    int kritikSans;
    int kalanBirimSayisi;
    Color color; // Birim rengi
    Texture2D texture; // PNG dosyası
    bool hasHeroEffect; // Kahraman etkisi var mı
    bool hasMonsterEffect; // Canavar etkisi var mı
} Birim;

// Function prototypes
void drawGrid(int cellSize, int rows, int cols);
Vector2 getBirimPosition(int rowIndex, int colIndex, int cellSize);
void loadOrkTextures(Birim *orkLegionu);
void unloadOrkTextures(Birim *orkLegionu, int count);
void loadInsanTextures(Birim *insanImparatorlugu);
void unloadInsanTextures(Birim *insanImparatorlugu, int count);
void drawHealthBar(Vector2 position, int currentHealth, int maxHealth, int cellSize, bool hasHeroEffect, bool hasMonsterEffect);
void drawBirimCount(Vector2 position, int currentHealth);
void placeUnitsInGrid(Birim *birimler, int birimCount, int cellSize, int startRow, int startCol);
void simulateBattle(Birim *insanImparatorlugu, int insanUnitCount, Birim *orkLegionu, int orkUnitCount);
char* downloadJSON(const char *url);
void simulateBattleWithJSON(char *jsonData);

// URL dizisi
const char *urlList[] = {
    "https://yapbenzet.org.tr/1.json",
    "https://yapbenzet.org.tr/2.json",
    "https://yapbenzet.org.tr/3.json",
    "https://yapbenzet.org.tr/4.json",
    "https://yapbenzet.org.tr/5.json",
    "https://bilgisayar.kocaeli.edu.tr/1.json",
    "https://bilgisayar.kocaeli.edu.tr/2.json",
    "https://bilgisayar.kocaeli.edu.tr/3.json",
    "https://bilgisayar.kocaeli.edu.tr/4.json",
    "https://bilgisayar.kocaeli.edu.tr/5.json"
};

// İndirilen veriyi saklamak için
struct MemoryStruct {
    char *memory;
    size_t size;
};

// Callback fonksiyonu
size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, struct MemoryStruct *mem) {
    size_t realsize = size * nmemb;
    mem->memory = realloc(mem->memory, mem->size + realsize + 1);
    if(mem->memory == NULL) return 0; // Bellek hatası

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;
    return realsize;
}

// JSON dosyasını indirme fonksiyonu
char* downloadJSON(const char *url) {
    CURL *curl;
    CURLcode res;
    struct MemoryStruct chunk;

    chunk.memory = malloc(1);
    chunk.size = 0;

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();

    if(curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
    }

    return chunk.memory;
}

int main(void) {
    const int ekranGenisligi = 800;
    const int ekranYuksekligi = 800;
    InitWindow(ekranGenisligi, ekranYuksekligi, "Savaş Simulasyonu");

    const int cellSize = 40; // Hücre boyutu 40 piksel
    const int rows = 20;     // Satır sayısı 20
    const int cols = 20;     // Sütun sayısı 20

    // İnsan birimlerini oluştur
    Birim insanImparatorlugu[] = {
        {"Kuşatma Makineleri", 100, 50, 100, 100, 0, 200, ORANGE, false, false},
        {"Okçular", 40, 20, 100, 100, 10, 400, DARKBLUE, true, false},  // Kahraman etkisi var
        {"Süvariler", 50, 30, 100, 100, 7, 300, RED, false, false},
        {"Piyadeler", 30, 40, 100, 100, 5, 500, DARKGREEN, true, false} // Kahraman etkisi var
    };
    int insanUnitCount = sizeof(insanImparatorlugu) / sizeof(insanImparatorlugu[0]);

    // Ork birimlerini oluştur
    Birim orkLegionu[] = {
        {"Ork Dövüşçüleri", 35, 25, 100, 100, 8, 500, DARKGRAY, false, true}, // Canavar etkisi var
        {"Mızrakçılar", 45, 20, 100, 100, 5, 400, MAROON, false, true},      // Canavar etkisi var
        {"Varg Binicileri", 55, 35, 100, 100, 6, 300, BROWN, false, false},
        {"Troller", 70, 40, 100, 100, 5, 200, DARKBLUE, false, true}         // Canavar etkisi var
    };
    int orkUnitCount = sizeof(orkLegionu) / sizeof(orkLegionu[0]);

    // PNG dosyalarını yükle
    loadInsanTextures(insanImparatorlugu);
    loadOrkTextures(orkLegionu);

    SetTargetFPS(60);

    // Senaryo seçimi
    int choice;
    printf("1 ile 10 arasında bir senaryo numarası girin: ");
    scanf("%d", &choice);
    if (choice < 1 || choice > 10) {
        printf("Geçersiz seçim! Program kapatılıyor.\n");
        CloseWindow();
        return 1;
    }

    // Seçilen URL'yi al
    const char *selectedURL = urlList[choice - 1];

    // JSON dosyasını indir
    char *jsonData = downloadJSON(selectedURL);
    if (jsonData) {
        // Savaş simülasyonunu başlat
        simulateBattleWithJSON(jsonData);
        free(jsonData); // Belleği temizle
    } else {
        printf("JSON dosyası indirilemedi!\n");
    }

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Izgarayı çiz
        drawGrid(cellSize, rows, cols);

        // İnsan birimlerini yerleştir (üst tarafta, sol)
        placeUnitsInGrid(insanImparatorlugu, insanUnitCount, cellSize, 1, 1);

        // Ork birimlerini yerleştir (alt tarafta, sağ)
        placeUnitsInGrid(orkLegionu, orkUnitCount, cellSize, 13, 1);

        EndDrawing();
    }

    unloadInsanTextures(insanImparatorlugu, insanUnitCount);
    unloadOrkTextures(orkLegionu, orkUnitCount);
    CloseWindow();
    return 0;
}

// Izgarayı çizme fonksiyonu
void drawGrid(int cellSize, int rows, int cols) {
    for (int i = 0; i <= cols; i++) {
        DrawLine(i * cellSize, 0, i * cellSize, GetScreenHeight(), LIGHTGRAY);
    }
    for (int j = 0; j <= rows; j++) {
        DrawLine(0, j * cellSize, GetScreenWidth(), j * cellSize, LIGHTGRAY);
    }
}

// Birimleri 18 kareye yayarak yerleştirme fonksiyonu
void placeUnitsInGrid(Birim *birimler, int birimCount, int cellSize, int startRow, int startCol) {
    for (int i = 0; i < birimCount; i++) {
        for (int j = 0; j < 18; j++) {
            int rowOffset = j / 3;  // 3 sütunluk bir yayılma
            int colOffset = j % 3;  // 3 hücre genişlikte

            Vector2 pozisyon = getBirimPosition(startRow + rowOffset, startCol + colOffset + (i * 4), cellSize);
            DrawTextureEx(birimler[i].texture, pozisyon, 0.5f, (float)cellSize / birimler[i].texture.width * 0.5f, WHITE);

            // Sağlık barını kahraman ve canavar etkisine göre çiz
            drawHealthBar(pozisyon, birimler[i].saglik, birimler[i].maksimumSaglik, cellSize, birimler[i].hasHeroEffect, birimler[i].hasMonsterEffect);
            drawBirimCount(pozisyon, birimler[i].saglik); // Can değerini göster
        }
    }
}

// Birimlerin pozisyonunu hesaplama fonksiyonu
Vector2 getBirimPosition(int rowIndex, int colIndex, int cellSize) {
    int x = colIndex * cellSize;
    int y = rowIndex * cellSize;
    return (Vector2){x, y};
}

// Sağlık barını çizme fonksiyonu
void drawHealthBar(Vector2 position, int currentHealth, int maxHealth, int cellSize, bool hasHeroEffect, bool hasMonsterEffect) {
    int barWidth = cellSize - 5;
    int barHeight = 8;
    float healthPercentage = (float)currentHealth / maxHealth;

    // Normal bar rengi
    Color barColor = (healthPercentage > 0.8) ? GREEN : (healthPercentage > 0.2 ? YELLOW : RED);

    // Kahraman veya canavar etkisi varsa parlak hale getir
    if (hasHeroEffect || hasMonsterEffect) {
        if (healthPercentage > 0.8) {
            barColor = LIME; // Parlak yeşil
        } else if (healthPercentage > 0.2) {
            barColor = GOLD; // Parlak sarı
        } else {
            barColor = MAROON; // Parlak kırmızı
        }
    }

    DrawRectangle(position.x, position.y - 9, barWidth * healthPercentage, barHeight, barColor);
}

// Birimlerin canını gösterme fonksiyonu
void drawBirimCount(Vector2 position, int currentHealth) {
    char buffer[10];
    sprintf(buffer, "%d", currentHealth); // Can değerini string'e çevir
    DrawText(buffer, position.x + 9, position.y - 9, 10, BLACK); // Konumu ortalayarak yazdır
}

// Ork birimlerinin PNG dosyalarını yükleme
void loadOrkTextures(Birim *orkLegionu) {
    orkLegionu[0].texture = LoadTexture("orklar.png");
    orkLegionu[1].texture = LoadTexture("mizrakci.png");
    orkLegionu[2].texture = LoadTexture("varg.png");
    orkLegionu[3].texture = LoadTexture("troll.png");
}

// İnsan birimlerinin PNG dosyalarını yükleme
void loadInsanTextures(Birim *insanImparatorlugu) {
    insanImparatorlugu[0].texture = LoadTexture("kusatma.png");
    insanImparatorlugu[1].texture = LoadTexture("okcu.png");
    insanImparatorlugu[2].texture = LoadTexture("suvari.png");
    insanImparatorlugu[3].texture = LoadTexture("piyade.png");
}

// Ork birimlerinin PNG dosyalarını boşaltma
void unloadOrkTextures(Birim *orkLegionu, int count) {
    for (int i = 0; i < count; i++) {
        UnloadTexture(orkLegionu[i].texture);
    }
}

// İnsan birimlerinin PNG dosyalarını boşaltma
void unloadInsanTextures(Birim *insanImparatorlugu, int count) {
    for (int i = 0; i < count; i++) {
        UnloadTexture(insanImparatorlugu[i].texture);
    }
}

// JSON verisini kullanarak savaş simülasyonu fonksiyonu
void simulateBattleWithJSON(char *jsonData) {
    // JSON verisini işleyebilir ve savaş simülasyonunu başlatabilirsin
    printf("JSON verisi indirildi: %s\n", jsonData);
    // Burada JSON işleme ve simülasyon kodunu ekle
}

// Savaş simülasyonu fonksiyonu
void simulateBattle(Birim *insanImparatorlugu, int insanUnitCount, Birim *orkLegionu, int orkUnitCount) {
    // Savaş simülasyonu kodu burada olacak (örnek olarak bırakıldı)
    printf("Savaş başlıyor...\n");

    for (int i = 0; i < insanUnitCount; i++) {
        printf("İnsan birimi: %s - Saldırı: %d\n", insanImparatorlugu[i].isim, insanImparatorlugu[i].saldiri);
    }

    for (int i = 0; i < orkUnitCount; i++) {
        printf("Ork birimi: %s - Saldırı: %d\n", orkLegionu[i].isim, orkLegionu[i].saldiri);
    }
}
